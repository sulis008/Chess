Project by Alexander Sulistyo (sulis008) and Travis Pham (pham0459)
Alex - Board, King, Rook, Bishop, Pawn Promotion
Travis - Piece, Game, Kight, Queen
Navigate to the file location on terminal.
Enter "javac Game.java"
Enter "java Game"
Play Chess!
Character spacing can be wonky depending on operating system
We certify that the information contained in this README file is complete and accurate.
We have both read and followed the course policies in the ‘Academic Integrity - Course Policy’
section of the course syllabus.